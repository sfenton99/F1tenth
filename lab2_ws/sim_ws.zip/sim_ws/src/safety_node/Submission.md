# Lab 2: Emergency Breaking

## Video Link: https://youtu.be/bGAdPxf1OKA