# Lab 3: Wall Following

## YouTube video links
Simulator (individual) : [sfenton Wall Following Video](https://youtu.be/nAUeWOjuPss)

Hardware (group) : [Wall Following around turn in the AI Makerspace!](https://youtu.be/qWendkbM0qM)
